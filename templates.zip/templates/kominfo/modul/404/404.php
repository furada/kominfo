		
		
		
		
  <!--========= HALAMAN ERROR ========================-->
  <section class="inner-container clearfix">
  <section id="content" class="eight column row pull-left">

  <div class="page-container error-404">
  <p>error <b>404</b><span>Maaf halaman yang anda cari tidak dapat ditemukan. Atau telah dihapus.</span></p>
  </div>
				
  </section>
  <!--========= AKHIR HALAMAN ERROR ========================-->


  <!--========= SIDEBAR ========================-->
  <?php include "$f[folder]/modul/sidebar/sidebar_home.php";?>
  <!--========= AKHIR SIDEBAR =================-->			
								